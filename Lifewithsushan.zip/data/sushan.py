# SHRISTI_TIMALSINA, SUSHAN_KC_KHATRI
# NP069970, NP069986
from datetime import datetime, date

def dict_to_text(dict):
    temp_str = ""
    for key, value in dict.items():
        temp_str += f"{key}={value},"
    temp_str = temp_str.rstrip(", ")
    return temp_str


def text_to_dict(text: str):
    text = text.strip()
    result_dict = {}
    splitted = text.split(",")
    for el in splitted:
        if "=" in el:
            key, val = el.split("=", 1)
            result_dict[key.strip()] = val.strip()
    return result_dict
def array_to_text(array):
    res = ""
    for dict in array:
        res += f" {dict_to_text(dict)} \n"
    res = res.rstrip("\n")
    return res
def file_text_to_array(location: str):
    arr = []
    with open(location) as file:
        for lines in file:
            if lines:
                dict = text_to_dict(lines)
                arr.append(dict)
    return arr


file_text_to_array("data.txt")


def generate_unique_id():
    now = datetime.now()
    id = now.strftime("%Y%m%d%H%M%S%f")
    return id

# utils ends here
from datetime import datetime, date
def is_valid_password(password):
    """Check if the password meets the criteria:
       - At least 8 characters long
       - Contains at least one uppercase letter
       - Contains at least one lowercase letter
       - Contains at least one digit
       - Contains at least one special character
    """
    # Check minimum length
    if len(password) < 8:
        return False
    
    # Flags for validation checks
    has_upper = False
    has_lower = False
    has_digit = False
    has_special = False
    
    # Special characters list
    special_chars = "!@#Rs%^&*()_+{}|:\"<>?`~"
    
    for char in password:
        if char.isupper():
            has_upper = True
        elif char.islower():
            has_lower = True
        elif char.isdigit():
            has_digit = True
        elif char in special_chars:
            has_special = True
    
    # Return True only if all conditions are met
    return has_upper and has_lower and has_digit and has_special


def get_all_customers():
    customer_file = "data/customers.txt"
    arrayed = file_text_to_array(customer_file)
    return arrayed


def customer_exits(id):
    print("customer exists id", id)
    customer_file = "data/customers.txt"
    found = False
    arrayed = file_text_to_array(customer_file)
    print("arrayed", arrayed)
    for el in arrayed:
        if el["id"] == id:
            found = True
            break
    return found


def get_transactions_by_customer_id(customer_id):
    transaction_array = file_text_to_array("data/transactions.txt")
    all_trans = list(
        filter(lambda x: x["customer_id"] == customer_id, transaction_array)
    )
    return all_trans


def calculate_total_withdrawals(transactions):
    return sum(int(transaction["withdraw"]) for transaction in transactions)


def calculate_total_deposits(transactions):
    return sum(int(transaction["deposit"]) for transaction in transactions)


def get_total_deposit_of_customer(customer_id):
    all_trans = get_transactions_by_customer_id(customer_id)
    return sum(int(transaction["deposit"]) for transaction in all_trans)


def get_customer_bank_balance(customer_id):
    all_trans = get_transactions_by_customer_id(customer_id)
    deposits = calculate_total_deposits(transactions=all_trans)
    withdraws = calculate_total_withdrawals(transactions=all_trans)
    balance = deposits - withdraws
    return {"deposits": deposits, "withdraws": withdraws, "balance": balance}


def calculate_current_balance_of_customer(customer_id):
    all_transactions = get_transactions_by_customer_id(customer_id)
    total_withdrawals = calculate_total_withdrawals(all_transactions)
    total_deposits = calculate_total_deposits(all_transactions)
    return total_deposits - total_withdrawals


def write_deposit_to_file(customer_id, amount):
    today = date.today()
    formatted_date = today.strftime("%Y-%m-%d")
    bank_balance = get_customer_bank_balance(customer_id)

    payload = {
        "date": formatted_date,
        "customer_id": customer_id,
        "withdraw": 0,
        "deposit": amount,
        "balance": bank_balance["balance"] + int(amount),
    }
    stringified = dict_to_text(payload)
    with open("data/transactions.txt", "a") as file:
        file.write(f"{stringified}\n")


def write_withdraw_to_file(customer_id, amount):
    today = date.today()
    formatted_date = today.strftime("%Y-%m-%d")
    bank_balance = get_customer_bank_balance(customer_id)

    payload = {
        "date": formatted_date,
        "customer_id": customer_id,
        "withdraw": amount,
        "deposit": 0,
        "balance": bank_balance["balance"] - int(amount),
    }
    stringified = dict_to_text(payload)
    with open("data/transactions.txt", "a") as file:
        file.write(f"{stringified}\n")


def deposit(customer_id, amount):
    if not amount.isdigit() or int(amount) <= 0:
        print("Invalid amount. Please enter a positive number.")
        return

    exists = customer_exits(customer_id)
    if not exists:
        print("Customer doesn't exist")
        return None
    else:
        write_deposit_to_file(customer_id, amount)
        print(f"Rs{amount} has been deposited to your account.")


def get_customer_by_id(customer_id):
    customers = get_all_customers()
    for customer in customers:
        if customer["id"] == customer_id:
            return customer
    return None


def withdraw(customer_id, amount):
    if not amount.isdigit() or int(amount) <= 0:
        print("Invalid amount. Please enter a positive number.")
        return

    exists = customer_exits(customer_id)
    if not exists:
        print("Customer doesn't exist")
        return None

    total_balance = calculate_current_balance_of_customer(customer_id)
    customer = get_customer_by_id(customer_id)
    account_type = customer["account_type"]
    min_balance = 100 if account_type == "savings" else 500
    if int(total_balance) - int(amount) < min_balance:
        print(
            f"Cannot withdraw. Minimum balance for a {account_type} account is Rs{min_balance}."
        )
    elif int(total_balance) < int(amount):
        print("Insufficient balance for withdrawal.")
    else:
        write_withdraw_to_file(customer_id, amount)
        print(f"Rs{amount} has been withdrawn from your account.")


def validate_customer_credentials():
    while True:
        account_no = input("Enter your account_no: ")
        if account_no == "\\q":
            return None

        password = input("Enter your password: ")
        if password == "\\q":
            return None
        all_customers = get_all_customers()
        for customer in all_customers:
            if (
                customer.get("id") == account_no
                and customer.get("password") == password
            ):
                return customer

        print(
            "Invalid account_no or password. Please try again or enter '\\q' to quit."
        )


def show_customer_options(customer):
    while True:
        print("\nCustomer Options:")
        print("1. Check Balance")
        print("2. Deposit")
        print("3. Withdraw")
        print("4. Change Password")
        print("5. Generate Report")
        print("6. Logout")

        choice = input("Enter your choice (1-6): ")

        if choice == "1":
            balance = calculate_current_balance_of_customer(customer["id"])
            print(f"Your current balance is: Rs{balance}")
        elif choice == "2":
            amount = input("Enter deposit amount: Rs")
            deposit(customer["id"], amount)
        elif choice == "3":
            amount = input("Enter withdrawal amount: Rs")
            withdraw(customer["id"], amount)
        elif choice == "4":
            change_customer_password(customer)
        elif choice == "5":
            generate_customer_report(customer["id"])
        elif choice == "6":
            print("Logging out...")
            break
        else:
            print("Invalid choice. Please try again.")


def generate_customer_report(customer_id):
    start_date = input("Enter start date (YYYY-MM-DD): ")
    end_date = input("Enter end date (YYYY-MM-DD): ")
    if not validate_date(start_date) or not validate_date(end_date):
        print("Invalid date format. Please use YYYY-MM-DD.")
        return
    transactions = get_transactions_by_date_range(customer_id, start_date, end_date)
    if not transactions:
        print("No transactions found for the given date range.")
        return
    print("\nTransaction Report")
    print("------------------")
    print("Date       | Type     | Amount  | Balance")
    print("------------------------------------------")
    for transaction in transactions:
        trans_type = "Deposit" if int(transaction["deposit"]) > 0 else "Withdraw"
        amount = (
            transaction["deposit"]
            if trans_type == "Deposit"
            else transaction["withdraw"]
        )
        print(
            f"{transaction['date']} | {trans_type:<8} | Rs{amount:<7} | Rs{transaction['balance']}"
        )
    total_deposits = sum(int(t["deposit"]) for t in transactions)
    total_withdrawals = sum(int(t["withdraw"]) for t in transactions)
    net_change = total_deposits - total_withdrawals
    print("\nSummary:")
    print(f"Total Deposits: Rs{total_deposits}")
    print(f"Total Withdrawals: Rs{total_withdrawals}")
    print(f"Net Change: Rs{net_change}")
    print(f"Final Balance: Rs{transactions[-1]['balance']}")
def get_transactions_by_date_range(customer_id, start_date, end_date):
    all_transactions = get_transactions_by_customer_id(customer_id)
    return [t for t in all_transactions if start_date <= t["date"] <= end_date]


def validate_date(date_string):
    try:
        datetime.datetime.strptime(date_string, "%Y-%m-%d")
        return True
    except ValueError:
        return False


def change_customer_password(customer):
    current_password = input("Enter your current password: ")
    if current_password != customer["password"]:
        print("Incorrect current password.")
        return
    while True:
      new_password = input("Enter your new password: ")
      if not is_valid_password(new_password):
          print("new password does not meet the criteria. please try again.")
          continue
      confirm_password = input("Confirm your new password: ")

      if new_password != confirm_password:
        print("New passwords do not match.")
        continue
      break

    update_customer_password(customer["id"], new_password)
    print("Password changed successfully.")


def update_customer_password(customer_id, new_password):
    customers = get_all_customers()
    for customer in customers:
        if customer["id"] == customer_id:
            customer["password"] = new_password
            customer["updated_at"] = date.today().strftime("%Y-%m-%d")
            break

    with open("data/customers.txt", "w") as file:
        for customer in customers:
            text = dict_to_text(customer)
            file.write(f"{text}\n")


def customer_login():
    print("Customer Login")
    print("______________")

    customer = validate_customer_credentials()

    if customer:
        print(f"Welcome, {customer['name']}!")
        show_customer_options(customer)
    else:
        print("Login cancelled.")


def create_customer():
    id = generate_unique_id()
    created_at = date.today()
    updated_at = date.today()
    name = input("Enter your name: ")
    while True:
     password = input("Create password: ")
     if not is_valid_password(password):
         print ("sorry, password does not meet the criteria.Please try again.")
         continue
     break

    # Validate account type
    account_type = None
    while account_type not in ("savings", "current"):
        account_type = input("Choose your account type (savings/current): ").lower()
        if account_type not in ("savings", "current"):
            print("Invalid account type. Please enter either 'savings' or 'current'.")
        

    # Ensure the
    # Ensure the minimum deposit requirement is met
    while True:
        initial_deposit = input("Enter initial deposit amount: Rs")
        if not initial_deposit.isdigit() or int(initial_deposit) <= 0:
            print("Invalid amount. Please enter a positive number.")
            continue

        initial_deposit = int(initial_deposit)

        if account_type == "savings" and initial_deposit < 100:
            print("Minimum deposit for a savings account is Rs100.")
        elif account_type == "current" and initial_deposit < 500:
            print("Minimum deposit for a current account is Rs500.")
        else:
            break

    # Write the new customer to the file
    data = {
        "id": id,
        "created_at": created_at.strftime("%Y-%m-%d"),
        "updated_at": updated_at.strftime("%Y-%m-%d"),
        "name": name,
        "password": password,
        "account_type": account_type,
        "initial_deposit": initial_deposit,
    }

    text = dict_to_text(data)
    with open("data/customers.txt", "a") as file:
        file.write(f"{text}\n")

    # Record the initial deposit as a transaction
    write_deposit_to_file(id, initial_deposit)
    print(
        f"Account created successfully with an initial deposit of Rs{initial_deposit}."
    )


def main():
    while True:
        print("\nWelcome to the Banking System")
        print("1. Create Customer Account")
        print("2. Customer Login")
        print("3. Exit")

        choice = input("Enter your choice (1-3): ")

        if choice == "1":
            create_customer()
        elif choice == "2":
            customer_login()
        elif choice == "3":
            print("Thank you for using the Banking System. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

def create_staff_prompt():
    username = input("Enter username: ")
    if does_username_exists(username):
        print("Username already exists. Please enter another username.")
        username = input("Enter unique username: ")
    name = input("Enter staff name: ")
    password = input("Enter password: ")
    if not is_valid_password(password):
      print("Sorry, password does not meet the criteria.")
      return  
    is_superuser = input("Is user a super user? [Y/N] ").lower()
    if is_superuser not in ("y", "n"):
        print("We only support Y/N for super user.")
        is_superuser = input("Is user a super user? [Y/N] ").lower()
    super_user_status = True if is_superuser == "y" else False
    create_staff(username, name, password, super_user_status)

def create_staff(username, name, password, super_user_status):
    if not is_valid_password(password):
        print("Sorry, password does not meet the criteria.")
        return
    id = generate_unique_id()
    text = dict_to_text(
        {
            "id": id,
            "username": username,
            "name": name,
            "password": password,
            "is_superuser": super_user_status,
        }
    )
    with open("data/staff.txt", "a") as file:
        file.write(f"{text}\n")
    print(f"Staff account for {name} has been created successfully.")


def create_customer():
    id = generate_unique_id()
    created_at = date.today()
    updated_at = date.today()
    name = input("Enter your name: ")
    password = input("Create password: ")
    if not is_valid_password(password):
        print("sorry, possword doesnot meet the criteria.")
        return False

    # Loop until a valid account type is provided
    account_type = None
    while account_type not in ("savings", "current"):
        account_type = input("Choose your account type (savings/current): ").lower()
        if account_type not in ("savings", "current"):
            print("Invalid account type. Please enter either 'savings' or 'current'.")
    # Ensure the
    # Ensure the minimum deposit requirement is met
    while True:
        initial_deposit = input("Enter initial deposit amount: Rs")
        if not initial_deposit.isdigit() or int(initial_deposit) <= 0:
            print("Invalid amount. Please enter a positive number.")
            continue

        initial_deposit = int(initial_deposit)

        if account_type == "savings" and initial_deposit < 100:
            print("Minimum deposit for a savings account is Rs100.")
        elif account_type == "current" and initial_deposit < 500:
            print("Minimum deposit for a current account is Rs500.")
        else:
            break

    data = {
        "id": id,
        "created_at": created_at,
        "updated_at": updated_at,
        "name": name,
        "password": password,
        "account_type": account_type,
        "initial_deposit": initial_deposit,

    }
    text = dict_to_text(data)
    with open("data/customers.txt", "a") as file:
        file.write(f"{text}\n")
# Record the initial deposit as a transaction
    try:
        write_deposit_to_file(id, initial_deposit)
    except Exception as e:
        print (f"error recording seposit:{e}")
        return False
    print(
        f"Account created successfully with an initial deposit of Rs{initial_deposit}.")
    return True



def edit_customer(name, new_name=None, new_password=None, new_deposit=None):
    customers = file_text_to_array("data/customers.txt")

    for customer in customers:
        if customer["name"] == name:
            if new_name:
                customer["name"] = new_name
            if new_password:
                customer["password"] = new_password
            if new_deposit:
                customer["deposit"] = new_deposit
            customer["updated_at"] = datetime.today()
            break

    with open("data/customers.txt", "w") as file:
        for customer in customers:
            text = dict_to_text(customer)
            file.write(f"{text}\n")


def customer_exits(id):
    customer_file = "data/customers.txt"
    found = False
    arrayed = file_text_to_array(customer_file)
    for el in arrayed:
        if el["id"] == id:
            found = True
            break
    return found


def get_all_customers():
    customer_file = "data/customers.txt"
    arrayed = file_text_to_array(customer_file)
    return arrayed


def validate_date(date_string):
    if len(date_string) != 10:
        return False
    if date_string[4] != "-" or date_string[7] != "-":
        return False
    try:
        return datetime.strptime(date_string, "%Y-%m-%d")
    
    except ValueError:
        return False


def get_all_transactions():
    arrayed = file_text_to_array("data/transactions.txt")
    return arrayed


def print_report(report):
    for re in report:
        print(
            "Date   ",
            re["date"],
            "||",
            "WithDraw   ",
            re["withdraw"],
            "||",
            "Deposit   ",
            re["deposit"],
        )
def generate_report():
    customer_id = input("Enter customer id: ")
    start_date = input("Enter start date (YYYY-MM-DD): ")
    end_date = input("Enter end date (YYYY-MM-DD): ")

    if not validate_date(start_date) or not validate_date(end_date):
        print("Invalid date format. Please use YYYY-MM-DD.")
        return

    transactions = get_transactions_by_date_range(customer_id, start_date, end_date)
    if not transactions:
        print("No transactions found for the given date range.")
        return
    print("\nTransaction Report")
    print("------------------")
    print("Date       | Type     | Amount  | Balance")
    print("------------------------------------------")

    for transaction in transactions:
        trans_type = "Deposit" if int(transaction["deposit"]) > 0 else "Withdraw"
        amount = (
            transaction["deposit"]
            if trans_type == "Deposit"
            else transaction["withdraw"]
        )
        print(
            f"{transaction['date']} | {trans_type:<8} | Rs{amount:<7} | Rs{transaction['balance']}"
        )
    total_deposits = sum(int(t["deposit"]) for t in transactions)
    total_withdrawals = sum(int(t["withdraw"]) for t in transactions)
    net_change = total_deposits - total_withdrawals
    print("\nSummary:")
    print(f"Total Deposits: Rs{total_deposits}")
    print(f"Total Withdrawals: Rs{total_withdrawals}")
    print(f"Net Change: Rs{net_change}")
    print(f"Final Balance: Rs{transactions[-1]['balance']}")


def get_transactions_by_date_range(customer_id, start_date, end_date):
    all_transactions = get_transactions_by_customer_id(customer_id)
    return [t for t in all_transactions if start_date <= t["date"] <= end_date]

def create_superuser():
    if does_superuser_exists():
        return
    create_staff("admin", "bank", "Bank@123", True)


def get_all_staffs():
    staffs = file_text_to_array("data/staff.txt")
    return staffs


def is_superuser(staff_id):
    staffs = get_all_staffs()
    for staff in staffs:
        if staff.get("id") == staff_id:
            return staff.get("is_superuser", False)
    return False


def does_username_exists(username):
    staffs = get_all_staffs()
    for staff in staffs:
        if staff.get("username") == username:
            return True
    return False


def does_superuser_exists():
    staffs = get_all_staffs()
    for staff in staffs:
        if staff.get("is_superuser") == "True":
            return True
    return False


def get_user_by_username(username):
    staffs = get_all_staffs()
    for staff in staffs:
        if staff.get("username") == username:
            return staff
    return None


def validate_password(username, password):
    user_data = get_user_by_username(username)
    if user_data and (user_data.get("password")) == password:
        return True
    return False


def show_admin_choices():
    while True:
        print("\nAdmin Options:")
        print("1. Create Customer account")
        print("2. Create staff user")
        print("3. Generate report")
        print("4. Edit customer details")
        print("5. Exit")

        code = input("Enter your choice here: ")
        if code == "1":
            create_customer()
        elif code == "2":
            create_staff_prompt()
        elif code == "3":
            generate_report()
        elif code == "4":
            edit_customer_details()
        elif code == "5":
            print("Exiting admin menu...")
            break
        else:
            print("Invalid choice. Please try again.")


def edit_customer_details():
    customer_id = input("Enter customer ID: ")
    if not customer_exits(customer_id):
        print("Customer doesn't exist.")
        return

    customer = get_customer_by_id(customer_id)
    if not customer:
        print("Error retrieving customer details.")
        return

    print("\nCurrent customer details:")
    print(f"Name: {customer['name']}")
    print(f"password:{customer['password']}")
    print(f"Account Type: {customer['account_type']}")

    new_name = input("Enter new name (or press Enter to keep current): ")
    new_password= input ("enter new password(or press enterto keep current password):")

    # Validate new account type

    new_account_type = None
    while new_account_type not in ("", "savings", "current"):
        new_account_type = input(
            "Enter new account type (savings/current) (or press Enter to keep current): "
        ).lower()
        if new_account_type not in ("", "savings", "current"):
            print("Invalid account type. Please enter either 'savings' or 'current'.")

    if new_name or new_password or new_account_type:
        update_customer_details(customer_id, new_name,new_password, new_account_type)
        print("Customer details updated successfully.")
    else:
        print("No changes made to customer details.")


def get_customer_by_id(customer_id):
    customers = get_all_customers()
    for customer in customers:
        if customer["id"] == customer_id:
            return customer
    return None


def update_customer_details(customer_id, new_name=None, new_password=None, new_account_type=None):
    customers = get_all_customers()
    for customer in customers:
        if customer["id"] == customer_id:
            if new_name:
                customer["name"] = new_name
            if new_password:
                customer["password"] = new_password   
            if new_account_type:
                customer["account_type"] = new_account_type
            customer["updated_at"] = date.today().strftime("%Y-%m-%d")
            break
    with open("data/customers.txt", "w") as file:
        for customer in customers:
            text = dict_to_text(customer)
            file.write(f"{text}\n")


def validate_admin():
    username = input("Enter your username: ")
    user_exists = does_username_exists(username)
    if not user_exists:
        print("User does not exist!")
        print("Press \\q to exit")
        username = input("Enter correct username: ")
        if username == "\\q":
            return False
        user_exists = does_username_exists(username)
        if not user_exists:
            print("user does not exist!")
            return False

    password = input("Enter your password: ")
    is_auth = validate_password(username, password)
    if is_auth:
        return True
    else:
        print("Username or password is invalid")
        print("Press \\q to quit")
        password = input("Enter your correct password: ")
        if password == "\\q":
            return False
        if not is_valid_password(password):
            print("Sorry, password does not meet the criteria.")
            return False
        return validate_password(username, password)


def login_as_admin():
    if validate_admin():
        show_admin_choices()
    else:
        print("Admin login failed.")


def show_multiple_choice_questions():
    print("Welcome to Brother and Sister Development Bank")
    print("____________________")
    print("1. Login as an Admin")
    print("2. Login as a customer")
    print("3. Exit")
    code = input("Enter a choice: ")
    if code == "1":
        login_as_admin()
    elif code == "2":
        customer_login()
    elif code == "3":
        print("Exit from system")
        exit()
    else:
        print("Invalid command")

def setup():
    create_superuser()
    show_multiple_choice_questions()


setup()
